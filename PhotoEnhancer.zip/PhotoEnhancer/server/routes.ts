import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { insertImageEnhancementSchema, enhancementOptionsSchema } from "@shared/schema";
import { z } from "zod";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPG, PNG, and WEBP files are allowed.'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Create uploads directory if it doesn't exist
  const uploadsDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }

  // Upload image endpoint
  app.post("/api/upload", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const enhancement = await storage.createImageEnhancement({
        originalFileName: req.file.originalname,
        originalFileSize: req.file.size,
        enhancedFileName: null,
        enhancedFileSize: null,
        status: "pending",
        enhancementOptions: null,
        processingStarted: null,
        processingCompleted: null,
      });

      res.json({
        id: enhancement.id,
        originalFileName: enhancement.originalFileName,
        originalFileSize: enhancement.originalFileSize,
        status: enhancement.status,
        filePath: req.file.path,
        originalImageUrl: `/api/files/${req.file.filename}`,
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // Start enhancement processing
  app.post("/api/enhance/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const options = enhancementOptionsSchema.parse(req.body);

      const enhancement = await storage.getImageEnhancement(id);
      if (!enhancement) {
        return res.status(404).json({ message: "Enhancement not found" });
      }

      // Update status to processing
      await storage.updateImageEnhancement(id, {
        status: "processing",
        enhancementOptions: JSON.stringify(options),
        processingStarted: new Date(),
      });

      // Simulate AI processing time
      setTimeout(async () => {
        try {
          // In a real implementation, this would call an AI service
          // For now, we'll simulate the enhancement completion
          const enhancedFileName = `enhanced_${enhancement.originalFileName}`;
          const enhancedFileSize = Math.floor(enhancement.originalFileSize * 1.2); // Simulate slightly larger file

          await storage.updateImageEnhancement(id, {
            status: "completed",
            enhancedFileName,
            enhancedFileSize,
            processingCompleted: new Date(),
          });
        } catch (error) {
          console.error("Enhancement processing error:", error);
          await storage.updateImageEnhancement(id, {
            status: "failed",
            processingCompleted: new Date(),
          });
        }
      }, 5000); // 5 second processing simulation

      res.json({ message: "Enhancement started", status: "processing" });
    } catch (error) {
      console.error("Enhancement start error:", error);
      res.status(500).json({ message: "Failed to start enhancement" });
    }
  });

  // Get enhancement status
  app.get("/api/enhance/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const enhancement = await storage.getImageEnhancement(id);
      
      if (!enhancement) {
        return res.status(404).json({ message: "Enhancement not found" });
      }

      res.json(enhancement);
    } catch (error) {
      console.error("Get enhancement error:", error);
      res.status(500).json({ message: "Failed to get enhancement status" });
    }
  });

  // Serve uploaded files
  app.get("/api/files/:filename", (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(uploadsDir, filename);
    
    if (fs.existsSync(filePath)) {
      res.sendFile(path.resolve(filePath));
    } else {
      res.status(404).json({ message: "File not found" });
    }
  });

  // Download enhanced image (placeholder - would normally serve the actual enhanced file)
  app.get("/api/download/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const enhancement = await storage.getImageEnhancement(id);
      
      if (!enhancement || enhancement.status !== "completed") {
        return res.status(404).json({ message: "Enhanced image not available" });
      }

      // For now, we'll return the original file as enhanced
      // In a real implementation, this would serve the actual AI-enhanced file
      res.json({
        downloadUrl: `/api/files/${enhancement.originalFileName}`,
        filename: enhancement.enhancedFileName || enhancement.originalFileName,
      });
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Download failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
