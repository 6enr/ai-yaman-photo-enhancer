import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ImageComparison } from "@/components/image-comparison";
import { getEnhancementStatus, downloadEnhancedImage } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Download, Plus, CheckCircle, Facebook, Twitter, Instagram, Link } from "lucide-react";

export default function Results() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const uploadId = sessionStorage.getItem('uploadId');
  const originalFileName = sessionStorage.getItem('originalFileName') || 'photo.jpg';
  const originalFileSize = parseInt(sessionStorage.getItem('originalFileSize') || '0');
  const storedImageUrl = sessionStorage.getItem('originalImageUrl') || '';

  const { data: enhancement, isLoading } = useQuery({
    queryKey: ['/api/enhance', uploadId],
    queryFn: () => getEnhancementStatus(parseInt(uploadId!)),
    enabled: !!uploadId,
  });

  useEffect(() => {
    if (!uploadId) {
      setLocation('/');
    }
  }, [uploadId, setLocation]);

  const handleDownload = async () => {
    try {
      if (!uploadId) return;
      
      const downloadData = await downloadEnhancedImage(parseInt(uploadId));
      
      // Create a temporary link to download the image
      const link = document.createElement('a');
      link.href = downloadData.downloadUrl;
      link.download = downloadData.filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Download started",
        description: "Your enhanced photo is being downloaded",
      });
    } catch (error) {
      toast({
        title: "Download failed",
        description: "There was an error downloading your enhanced photo",
        variant: "destructive",
      });
    }
  };

  const handleEnhanceAnother = () => {
    // Clear session storage
    sessionStorage.removeItem('uploadId');
    sessionStorage.removeItem('originalFileName');
    sessionStorage.removeItem('originalFileSize');
    sessionStorage.removeItem('originalImageUrl');
    setLocation('/');
  };

  const handleShare = (platform: string) => {
    toast({
      title: "Share feature",
      description: `Share to ${platform} functionality would be implemented here`,
    });
  };

  if (isLoading || !enhancement) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading results...</p>
        </div>
      </div>
    );
  }

  if (enhancement.status !== 'completed') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Enhancement not completed yet. Redirecting...</p>
        </div>
      </div>
    );
  }

  // For now, use the same image for both before and after
  // In a real implementation, enhancedImageUrl would point to the AI-processed image
  const originalImageUrl = storedImageUrl;
  const enhancedImageUrl = storedImageUrl;

  return (
    <div className="animate-fade-in">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Results Header */}
        <div className="text-center mb-12">
          <Badge className="inline-flex items-center px-4 py-2 bg-green-100 text-green-800 hover:bg-green-100 mb-4">
            <CheckCircle className="w-4 h-4 mr-2" />
            Enhancement Complete
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Your Enhanced Photo</h2>
          <p className="text-lg text-gray-600">Compare the before and after results</p>
        </div>

        {/* Before/After Comparison */}
        <div className="mb-8">
          <ImageComparison
            originalImage={originalImageUrl}
            enhancedImage={enhancedImageUrl}
            originalSize={originalFileSize}
            enhancedSize={enhancement.enhancedFileSize || originalFileSize}
            originalFileName={originalFileName}
            enhancedFileName={enhancement.enhancedFileName || `enhanced_${originalFileName}`}
          />
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            onClick={handleDownload}
            className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 text-white font-semibold text-lg rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            <Download className="w-5 h-5 mr-3" />
            Download Enhanced Photo
          </Button>
          
          <Button
            onClick={handleEnhanceAnother}
            variant="outline"
            className="inline-flex items-center px-8 py-4 border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50 font-semibold text-lg rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5 mr-3" />
            Enhance Another Photo
          </Button>
        </div>

        {/* Share Options */}
        <div className="mt-12 text-center">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Share Your Enhanced Photo</h4>
          <div className="flex justify-center space-x-4">
            <Button
              onClick={() => handleShare('Facebook')}
              className="w-12 h-12 bg-blue-600 hover:bg-blue-700 rounded-lg"
            >
              <Facebook className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => handleShare('Twitter')}
              className="w-12 h-12 bg-blue-400 hover:bg-blue-500 rounded-lg"
            >
              <Twitter className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => handleShare('Instagram')}
              className="w-12 h-12 bg-pink-600 hover:bg-pink-700 rounded-lg"
            >
              <Instagram className="w-5 h-5" />
            </Button>
            <Button
              onClick={() => handleShare('Copy Link')}
              className="w-12 h-12 bg-gray-600 hover:bg-gray-700 rounded-lg"
            >
              <Link className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
