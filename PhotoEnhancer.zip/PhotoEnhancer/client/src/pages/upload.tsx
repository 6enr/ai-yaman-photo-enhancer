import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { FileUpload } from "@/components/file-upload";
import { uploadImage, startEnhancement } from "@/lib/api";
import type { EnhancementOptions } from "@shared/schema";
import { Zap, Shield, Download } from "lucide-react";

export default function Upload() {
  const [, setLocation] = useLocation();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [enhancementOptions, setEnhancementOptions] = useState<EnhancementOptions>({
    autoEnhance: true,
    sharpen: false,
    denoise: false,
  });

  const uploadMutation = useMutation({
    mutationFn: uploadImage,
    onSuccess: (data) => {
      // Store upload ID and image URL for the next step
      sessionStorage.setItem('uploadId', data.id.toString());
      sessionStorage.setItem('originalFileName', data.originalFileName);
      sessionStorage.setItem('originalFileSize', data.originalFileSize.toString());
      sessionStorage.setItem('originalImageUrl', data.originalImageUrl);
    },
  });

  const enhanceMutation = useMutation({
    mutationFn: ({ id, options }: { id: number; options: EnhancementOptions }) => 
      startEnhancement(id, options),
    onSuccess: () => {
      setLocation('/loading');
    },
  });

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
  };

  const handleEnhance = async () => {
    if (!selectedFile) return;

    try {
      const uploadResult = await uploadMutation.mutateAsync(selectedFile);
      await enhanceMutation.mutateAsync({
        id: uploadResult.id,
        options: enhancementOptions,
      });
    } catch (error) {
      console.error('Enhancement failed:', error);
    }
  };

  const handleOptionChange = (option: keyof EnhancementOptions, checked: boolean) => {
    setEnhancementOptions(prev => ({
      ...prev,
      [option]: checked,
    }));
  };

  return (
    <main className="animate-fade-in">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Enhance Your Photos with{" "}
            <span className="bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
              AI Yaman
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Transform your images instantly with our advanced AI technology. 
            Upload any photo and watch it come to life with enhanced colors, sharpness, and detail.
          </p>
        </div>

        {/* Upload Card */}
        <Card className="rounded-2xl shadow-xl border border-gray-200 overflow-hidden animate-slide-up">
          <CardContent className="p-8">
            
            <FileUpload
              onFileSelect={handleFileSelect}
              selectedFile={selectedFile}
              onRemoveFile={handleRemoveFile}
            />

            {/* Enhancement Options */}
            {selectedFile && (
              <div className="mt-8">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Enhancement Options</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  
                  <div className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg">
                    <Checkbox
                      id="auto-enhance"
                      checked={enhancementOptions.autoEnhance}
                      onCheckedChange={(checked) => handleOptionChange('autoEnhance', !!checked)}
                    />
                    <div>
                      <label htmlFor="auto-enhance" className="font-medium text-gray-900 cursor-pointer">
                        Auto Enhance
                      </label>
                      <div className="text-sm text-gray-600">Overall improvement</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg">
                    <Checkbox
                      id="sharpen"
                      checked={enhancementOptions.sharpen}
                      onCheckedChange={(checked) => handleOptionChange('sharpen', !!checked)}
                    />
                    <div>
                      <label htmlFor="sharpen" className="font-medium text-gray-900 cursor-pointer">
                        Sharpen
                      </label>
                      <div className="text-sm text-gray-600">Increase detail</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg">
                    <Checkbox
                      id="denoise"
                      checked={enhancementOptions.denoise}
                      onCheckedChange={(checked) => handleOptionChange('denoise', !!checked)}
                    />
                    <div>
                      <label htmlFor="denoise" className="font-medium text-gray-900 cursor-pointer">
                        Denoise
                      </label>
                      <div className="text-sm text-gray-600">Remove grain</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Enhance Button */}
            {selectedFile && (
              <div className="mt-8 text-center">
                <Button
                  onClick={handleEnhance}
                  disabled={uploadMutation.isPending || enhanceMutation.isPending}
                  className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-semibold text-lg rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <svg className="w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z" />
                  </svg>
                  <span>{uploadMutation.isPending || enhanceMutation.isPending ? 'Processing...' : 'Enhance Photo'}</span>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center group">
            <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-lg mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Lightning Fast</h3>
            <p className="text-gray-600">Get enhanced photos in seconds with our optimized AI processing</p>
          </div>
          
          <div className="text-center group">
            <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-lg mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Secure & Private</h3>
            <p className="text-gray-600">Your photos are processed securely and never stored on our servers</p>
          </div>
          
          <div className="text-center group">
            <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-lg mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <Download className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">High Quality</h3>
            <p className="text-gray-600">Download your enhanced photos in full resolution</p>
          </div>
        </div>
      </div>
    </main>
  );
}
