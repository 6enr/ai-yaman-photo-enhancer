import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Progress } from "@/components/ui/progress";
import { getEnhancementStatus } from "@/lib/api";

export default function Loading() {
  const [, setLocation] = useLocation();
  const [progressValue, setProgressValue] = useState(0);
  const [progressText, setProgressText] = useState("Initializing AI processing...");

  const uploadId = sessionStorage.getItem('uploadId');

  const { data: enhancement } = useQuery({
    queryKey: ['/api/enhance', uploadId],
    queryFn: () => getEnhancementStatus(parseInt(uploadId!)),
    refetchInterval: 1000, // Poll every second
    enabled: !!uploadId,
  });

  useEffect(() => {
    if (!uploadId) {
      setLocation('/');
      return;
    }

    const steps = [
      'Initializing AI processing...',
      'Analyzing image quality...',
      'Enhancing colors and contrast...',
      'Improving sharpness and details...',
      'Reducing noise and artifacts...',
      'Finalizing enhancement...'
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setProgressText(steps[currentStep]);
        setProgressValue(((currentStep + 1) / steps.length) * 100);
        currentStep++;
      }
    }, 800);

    return () => clearInterval(interval);
  }, [uploadId, setLocation]);

  useEffect(() => {
    if (enhancement?.status === 'completed') {
      setLocation('/results');
    } else if (enhancement?.status === 'failed') {
      setLocation('/');
    }
  }, [enhancement, setLocation]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <div className="w-32 h-32 mx-auto mb-8 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full animate-pulse"></div>
          <div className="absolute inset-2 bg-white rounded-full flex items-center justify-center">
            <svg className="w-12 h-12 text-indigo-600 animate-pulse" fill="currentColor" viewBox="0 0 20 20">
              <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z" />
            </svg>
          </div>
        </div>
        
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Enhancing Your Photo</h3>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          Our AI is working its magic to improve your image quality, colors, and details
        </p>
        
        {/* Progress Bar */}
        <div className="w-80 max-w-full mx-auto mb-4">
          <Progress value={progressValue} className="h-3" />
        </div>
        
        <div className="text-sm text-gray-500">
          <span>{progressText}</span>
        </div>
      </div>
    </div>
  );
}
