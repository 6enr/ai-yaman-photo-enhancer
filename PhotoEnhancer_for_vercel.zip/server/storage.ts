import { users, imageEnhancements, type User, type InsertUser, type ImageEnhancement, type InsertImageEnhancement } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createImageEnhancement(enhancement: InsertImageEnhancement): Promise<ImageEnhancement>;
  getImageEnhancement(id: number): Promise<ImageEnhancement | undefined>;
  updateImageEnhancement(id: number, updates: Partial<ImageEnhancement>): Promise<ImageEnhancement | undefined>;
  getAllImageEnhancements(): Promise<ImageEnhancement[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createImageEnhancement(enhancement: InsertImageEnhancement): Promise<ImageEnhancement> {
    const [imageEnhancement] = await db
      .insert(imageEnhancements)
      .values(enhancement)
      .returning();
    return imageEnhancement;
  }

  async getImageEnhancement(id: number): Promise<ImageEnhancement | undefined> {
    const [enhancement] = await db.select().from(imageEnhancements).where(eq(imageEnhancements.id, id));
    return enhancement || undefined;
  }

  async updateImageEnhancement(id: number, updates: Partial<ImageEnhancement>): Promise<ImageEnhancement | undefined> {
    const [updated] = await db
      .update(imageEnhancements)
      .set(updates)
      .where(eq(imageEnhancements.id, id))
      .returning();
    return updated || undefined;
  }

  async getAllImageEnhancements(): Promise<ImageEnhancement[]> {
    return await db.select().from(imageEnhancements);
  }
}

export const storage = new DatabaseStorage();
