import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const imageEnhancements = pgTable("image_enhancements", {
  id: serial("id").primaryKey(),
  originalFileName: text("original_file_name").notNull(),
  originalFileSize: integer("original_file_size").notNull(),
  enhancedFileName: text("enhanced_file_name"),
  enhancedFileSize: integer("enhanced_file_size"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed
  enhancementOptions: text("enhancement_options"), // JSON string of selected options
  processingStarted: timestamp("processing_started"),
  processingCompleted: timestamp("processing_completed"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertImageEnhancementSchema = createInsertSchema(imageEnhancements).omit({
  id: true,
  createdAt: true,
});

export const enhancementOptionsSchema = z.object({
  autoEnhance: z.boolean().default(true),
  sharpen: z.boolean().default(false),
  denoise: z.boolean().default(false),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type ImageEnhancement = typeof imageEnhancements.$inferSelect;
export type InsertImageEnhancement = z.infer<typeof insertImageEnhancementSchema>;
export type EnhancementOptions = z.infer<typeof enhancementOptionsSchema>;
