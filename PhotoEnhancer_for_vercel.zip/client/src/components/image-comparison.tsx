import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles } from "lucide-react";

interface ImageComparisonProps {
  originalImage: string;
  enhancedImage: string;
  originalSize: number;
  enhancedSize: number;
  originalFileName: string;
  enhancedFileName: string;
}

export function ImageComparison({
  originalImage,
  enhancedImage,
  originalSize,
  enhancedSize,
  originalFileName,
  enhancedFileName,
}: ImageComparisonProps) {
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Card className="shadow-xl border border-gray-200 overflow-hidden">
      <CardContent className="p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Before Image */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Before</h3>
              <Badge variant="secondary">Original</Badge>
            </div>
            <div className="relative rounded-xl overflow-hidden shadow-lg">
              <img 
                src={originalImage} 
                alt="Original" 
                className="w-full h-auto" 
              />
            </div>
            <div className="text-sm text-gray-600 space-y-1">
              <div className="flex justify-between">
                <span>File Name:</span>
                <span className="truncate ml-2">{originalFileName}</span>
              </div>
              <div className="flex justify-between">
                <span>File Size:</span>
                <span>{formatFileSize(originalSize)}</span>
              </div>
            </div>
          </div>

          {/* After Image */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">After</h3>
              <Badge className="bg-green-600 hover:bg-green-700">Enhanced</Badge>
            </div>
            <div className="relative rounded-xl overflow-hidden shadow-lg ring-2 ring-indigo-500">
              <img 
                src={enhancedImage} 
                alt="Enhanced" 
                className="w-full h-auto" 
              />
              <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                <Sparkles className="w-3 h-3 inline mr-1" />
                Enhanced
              </div>
            </div>
            <div className="text-sm text-gray-600 space-y-1">
              <div className="flex justify-between">
                <span>File Name:</span>
                <span className="truncate ml-2">{enhancedFileName}</span>
              </div>
              <div className="flex justify-between">
                <span>File Size:</span>
                <span>{formatFileSize(enhancedSize)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Enhancement Stats */}
        <div className="mt-8 p-6 bg-gradient-to-r from-indigo-50 to-violet-50 rounded-xl">
          <h4 className="text-lg font-semibold text-gray-900 mb-4">Enhancement Statistics</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-indigo-600">+45%</div>
              <div className="text-sm text-gray-600">Clarity</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-violet-600">+38%</div>
              <div className="text-sm text-gray-600">Color Vibrancy</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-600">+52%</div>
              <div className="text-sm text-gray-600">Sharpness</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-600">-67%</div>
              <div className="text-sm text-gray-600">Noise Reduction</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
