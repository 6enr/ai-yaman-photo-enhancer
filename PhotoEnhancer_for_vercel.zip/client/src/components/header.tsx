import { Link } from "wouter";

export function Header() {
  return (
    <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z" />
              </svg>
            </div>
            <h1 className="text-xl font-bold text-gray-900">AI Yaman Photo Enhancer</h1>
          </Link>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="text-gray-600 hover:text-indigo-600 transition-colors duration-200">
              Home
            </Link>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors duration-200">
              Gallery
            </a>
            <a href="#" className="text-gray-600 hover:text-indigo-600 transition-colors duration-200">
              Pricing
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}
