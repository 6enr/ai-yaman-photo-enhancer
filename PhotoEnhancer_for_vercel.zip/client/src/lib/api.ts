import { apiRequest } from "./queryClient";
import type { EnhancementOptions, ImageEnhancement } from "@shared/schema";

export const uploadImage = async (file: File) => {
  const formData = new FormData();
  formData.append("image", file);
  
  const response = await apiRequest("POST", "/api/upload", formData);
  return response.json();
};

export const startEnhancement = async (id: number, options: EnhancementOptions) => {
  const response = await apiRequest("POST", `/api/enhance/${id}`, options);
  return response.json();
};

export const getEnhancementStatus = async (id: number): Promise<ImageEnhancement> => {
  const response = await fetch(`/api/enhance/${id}`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    throw new Error(`Failed to get enhancement status: ${response.statusText}`);
  }
  
  return response.json();
};

export const downloadEnhancedImage = async (id: number) => {
  const response = await fetch(`/api/download/${id}`, {
    credentials: "include",
  });
  
  if (!response.ok) {
    throw new Error(`Download failed: ${response.statusText}`);
  }
  
  return response.json();
};
